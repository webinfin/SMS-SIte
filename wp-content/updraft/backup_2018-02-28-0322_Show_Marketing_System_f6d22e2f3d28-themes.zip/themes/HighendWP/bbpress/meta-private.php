<div class="bbp-template-notice not-logged-in">
	<p>Sorry, this forum is for verified users only. Please <a href="<?php echo site_url('/wp-login.php') ?>">Login</a> or <a href="<?php echo site_url('/wp-login.php?action=register') ?>">Register</a> to continue</p>
</div>