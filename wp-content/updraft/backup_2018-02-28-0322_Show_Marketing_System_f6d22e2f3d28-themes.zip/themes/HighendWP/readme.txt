Thank you for purchasing Highend WordPress Theme.

Theme documentation is located here:
http://documentation.hb-themes.com/highend

Thanks!
HB-Themes